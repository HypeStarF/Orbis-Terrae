# Bergen real-data atlas attribution

Elevation was produced using Copernicus WorldDEM-90 © DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.

The land mask was made with Natural Earth. Natural Earth data is public domain.
